import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { activityStatus } from './activity.mjs';
import { events, listRuns, status } from './loop.mjs';
import { mainModule, VERSION, validId } from './lib.mjs';
import { readCodexWorkspaces, resolveChatWorkspace, verifyCodexSubagent, resolveCodexSubagent } from './codex-workspaces.mjs';
import { themeCss } from './ui-theme.mjs';
import { createWorkflowGraph } from './workflow-graph.mjs';
import { chatHistory } from './dashboard.mjs';
import { userHome, resolveEffectiveProfile } from './profiles.mjs';
import { disabledProfile, roleEnabled } from './routing.mjs';
import { createSettingsManager } from './native-settings.mjs';

export const PROTOCOL_VERSION = '2025-11-25';
export const SERVER_NAME = 'ai-loop-engineering-settings';
export const SERVER_VERSION = VERSION;
export const READ_TOOL = 'ai_loop.settings.read';
export const UPDATE_TOOL = 'ai_loop.settings.update';
export const DASHBOARD_TOOL = 'ai_loop.dashboard';
export const DASHBOARD_READ_TOOL = 'ai_loop.dashboard.read';
export const DASHBOARD_URI = 'ui://ai-loop-engineering/agent-dashboard';
const dashboardPath = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../ui/agent-dashboard.html');
export const dashboardHtml = () => fs.readFileSync(dashboardPath, 'utf8')
  .replace('/* LOOP_THEME */', themeCss() + ';')
  .replace("/* LOOP_VERSION */'development'", JSON.stringify(VERSION))
  .replace('/* LOOP_GRAPH */', 'const createWorkflowGraph = ' + createWorkflowGraph.toString() + ';');
const MAX_LINE_BYTES = 1024 * 1024;

const readOutputSchema = {
  type: 'object',
  properties: {
    schema: { type: 'object' },
    values: { type: 'object' },
    layout: { type: 'array', items: { type: 'object' } },
  },
  required: ['schema', 'values'],
};
const updateOutputSchema = { type: 'object', properties: readOutputSchema.properties, required: ['values'] };
const objectSchema = { type: 'object', additionalProperties: false };
const actionSchema = { type: 'object', properties: {}, additionalProperties: false };

const toolList = [
  { name: READ_TOOL, title: '读取 AI Loop 设置', description: '读取插件原生设置页所需的字段和当前值。', inputSchema: objectSchema, outputSchema: readOutputSchema, annotations: { readOnlyHint: true } },
  { name: UPDATE_TOOL, title: '更新 AI Loop 设置草稿', description: '仅暂存发生变化的字段；点击应用按钮后才写入配置。', inputSchema: { type: 'object', properties: { set: { type: 'object', additionalProperties: { type: ['string', 'number', 'boolean'] }, minProperties: 1 } }, required: ['set'], additionalProperties: false, }, outputSchema: updateOutputSchema },
  { name: 'ai_loop.settings.apply', title: '应用设置', description: '统一保存工作区开关、已开启角色模型和并发设置；失败时回滚工作区开关。', inputSchema: actionSchema },
  { name: 'ai_loop.settings.discard', title: '放弃未应用草稿', description: '放弃当前范围草稿，重新打开页面后读取最新配置。', inputSchema: actionSchema },
  { name: 'ai_loop.settings.reset_project', title: '恢复项目默认', description: '移除本工具登记的项目模型覆盖并继承全局配置。', inputSchema: actionSchema },
  { name: DASHBOARD_TOOL, title: 'AI Loop 工作流', description: '仅在用户明确要求打开时显示工作流面板。提供真实root/session可定位；页面内部读取和刷新必须使用ai_loop.dashboard.read，不发送定位聊天消息。旧版binding打开入口已停用。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, session: { type: 'string' } }, additionalProperties: false }, outputSchema: { type: 'object', properties: { workspaces: { type: 'array' }, note: { type: 'string' } }, required: ['workspaces', 'note'] }, annotations: { readOnlyHint: true }, _meta: { ui: { resourceUri: DASHBOARD_URI }, 'openai/ui': { entrypoints: [{ type: 'thread' }, { type: 'global' }] } } },
  { name: DASHBOARD_READ_TOOL, title: '读取 AI Loop 工作流数据', description: '仅读取工作流看板数据。可提供真实 root/session；binding 仅用于兼容旧定位标识。此工具不会打开页面。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, session: { type: 'string' }, binding: { type: 'string' } }, additionalProperties: false }, outputSchema: { type: 'object', properties: { workspaces: { type: 'array' }, note: { type: 'string' } }, required: ['workspaces', 'note'] }, annotations: { readOnlyHint: true } },
  { name: 'ai_loop.panel.read', title: '读取工作流面板', description: '按面板实例读取配置和草稿。', inputSchema: { type: 'object', properties: { panel_id: { type: 'string' } }, required: ['panel_id'], additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: 'ai_loop.panel.update', title: '更新面板草稿', description: '只暂存当前面板的工作区配置。', inputSchema: { type: 'object', properties: { panel_id: { type: 'string' }, set: { type: 'object' } }, required: ['panel_id', 'set'], additionalProperties: false } },
  { name: 'ai_loop.panel.action', title: '保存或放弃面板草稿', description: '明确保存、放弃草稿或恢复继承。', inputSchema: { type: 'object', properties: { panel_id: { type: 'string' }, action: { type: 'string', enum: ['apply', 'discard', 'reset_project'] } }, required: ['panel_id', 'action'], additionalProperties: false } },
  { name: 'ai_loop.dashboard.runs', title: '读取工作区运行列表', description: '读取工作区运行；提供 session 时仅列出该聊天的运行。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, session: { type: 'string' } }, required: ['root'], additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: 'ai_loop.dashboard.status', title: '读取运行代理状态', description: '读取最后一次子代理观察及任务证据，不代表实时状态。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, run: { type: 'string' }, project_path: { type: 'string' }, session: { type: 'string' } }, required: ['root', 'run'], additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: 'ai_loop.dashboard.history', title: '读取当前聊天历次任务', description: '按真实父聊天 ID 筛选历次运行，未知归属的旧记录单独计数，不混入当前聊天。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, session: { type: 'string' }, after: { type: 'string' } }, required: ['root', 'session'], additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: 'ai_loop.dashboard.navigation.verify', title: '验证子代理聊天导航目标', description: '只读核对当前父聊天、工作区与 Codex 原生子线程索引；不打开页面、不发送聊天消息。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, session: { type: 'string' }, thread_id: { type: 'string' } }, required: ['root', 'session', 'thread_id'], additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: 'ai_loop.dashboard.navigation.resolve', title: '核对指定父聊天的子代理', description: '根据用户指定的父聊天与运行记录，只读核对子代理身份。', inputSchema: { type: 'object', properties: { root: { type: 'string' }, run: { type: 'string' }, project_path: { type: 'string' }, session: { type: 'string' }, agent_id: { type: 'string' } }, required: ['root', 'run', 'session', 'agent_id'], additionalProperties: false }, annotations: { readOnlyHint: true } },
];
for (const name of ['ai_loop.dashboard.runs', 'ai_loop.dashboard.history']) {
  const tool = toolList.find(item => item.name === name);
  tool.inputSchema.properties.workspace_id = { type: 'string' };
  tool.inputSchema.required = name.endsWith('.history') ? ['session'] : [];
  tool.inputSchema.anyOf = [{ required: ['root'] }, { required: ['workspace_id'] }];
}

function rpcError(id, code, message) { return { jsonrpc: '2.0', id, error: { code, message } }; }
function toolResult(structuredContent, text = '') {
  return { content: text ? [{ type: 'text', text }] : [], structuredContent };
}
function initializeResult() {
  return {
    protocolVersion: PROTOCOL_VERSION,
    serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
    capabilities: {
      tools: {}, resources: {},
      experimental: { 'openai/settings': { readTool: READ_TOOL, updateTool: UPDATE_TOOL } },
    },
  };
}

export function createSettingsProtocol(manager = createSettingsManager(), options = {}) {
  const home = () => options.home || userHome();
  const panels = new Map();
  const bindings = new Map();
  const panelFor = (id, create) => {
    if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{8,100}$/.test(id)) throw new Error('面板实例标识无效');
    if (!panels.has(id)) {
      if (!create) throw new Error('面板实例已回收，请刷新工作区后重试');
      if (panels.size >= 64) {
        const clean = [...panels].find(([, panel]) => panel.hasDrafts?.() === false);
        if (!clean) throw new Error('面板草稿已达上限，请先保存或放弃已有面板的草稿');
        panels.delete(clean[0]);
      }
      panels.set(id, options.managerFactory ? options.managerFactory() : createSettingsManager({ ...options.managerOptions, home: home() }));
    }
    return panels.get(id);
  };
  const discoveredRoot = value => {
    if (typeof value !== 'string') throw new Error('须选择当前存在的 Codex 工作区');
    const normalize = root => process.platform === 'win32' ? path.resolve(root).toLowerCase() : path.resolve(root);
    const found = readCodexWorkspaces(home()).workspaces.find(item => (item.roots || [item.root]).some(root => normalize(root) === normalize(value)));
    if (!found) throw new Error('只能读取 Codex 已发现且当前存在的精确工作区');
    return (found.roots || [found.root]).find(root => normalize(root) === normalize(value));
  };
  const navigationProof = (root, session, threadId, workspace = resolveChatWorkspace(home(), session)) => {
    const samePath = (left, right) => process.platform === 'win32' ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase() : path.resolve(left) === path.resolve(right);
    if (!workspace || !workspace.roots.some(member => samePath(member, root))) return { available: false, reason: '父聊天不属于当前工作区' };
    return verifyCodexSubagent(home(), { threadId, parentThreadId: session, roots: workspace.roots });
  };
  const navigationActivity = (root, session, activity, workspace) => ({
    ...activity,
    agents: (activity?.agents ?? []).map(agent => {
      const threadId = [agent.session_id, agent.context?.id, agent.native_id].find(value => typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value));
      if (agent.harness !== 'codex' || agent.context?.parent_id !== session)
        return { ...agent, navigation: { available: false, reason: '缺少当前工作区内可验证的子会话身份' } };
      if (threadId) return { ...agent, navigation: navigationProof(root, session, threadId, workspace) };
      const belongs = workspace?.roots?.some(member => process.platform === 'win32' ? path.resolve(member).toLowerCase() === path.resolve(root).toLowerCase() : path.resolve(member) === path.resolve(root));
      const navigation = belongs ? resolveCodexSubagent(home(), { agentPath: agent.native_id, agentRole: `loop-${agent.role}`, parentThreadId: session, roots: workspace.roots }) : { available: false, reason: '父聊天不属于当前工作区' };
      return { ...agent, ...(navigation.available ? { session_id: navigation.thread_id } : {}), navigation };
    }),
  });
  const sessionRuns = (root, session) => {
    if (typeof session !== 'string' || !session.trim() || session.length > 1000) throw new Error('须提供真实聊天标识');
    const rounds = []; let after;
    do { const page = chatHistory(root, { session_id: session, harness: 'codex', limit: 100, after }); rounds.push(...page.rounds); after = page.next_after; } while (after);
    return rounds;
  };
  const dashboardData = args => {
    if (Object.keys(args).some(key => !['root', 'session', 'binding'].includes(key))) throw new Error('看板仅接受 root/session/binding');
    const binding = args.binding;
    let bindingEntry;
    if (binding !== undefined) {
      if (typeof binding !== 'string' || !/^[A-Za-z0-9_-]{16,160}$/.test(binding)) throw new Error('定位请求标识无效');
      for (const [key, value] of bindings) if (Date.now() - value.created > 10 * 60 * 1000) bindings.delete(key);
      if (!bindings.has(binding)) {
        if (args.root || args.session) throw new Error('定位请求已失效，请重新打开面板');
        if (bindings.size >= 128) throw new Error('定位请求过多，请稍后重试');
        bindings.set(binding, { created: Date.now(), context: null });
      }
      bindingEntry = bindings.get(binding);
      bindingEntry.created = Date.now();
      const stored = bindingEntry.context;
      if (stored && !args.root && !args.session) args = { ...args, root: stored.root, ...(stored.session ? { session: stored.session } : {}) };
    }
    if (args.session !== undefined && (typeof args.session !== 'string' || !args.session.trim() || args.session.length > 1000)) throw new Error('聊天定位需要真实 session');
    const discovery = readCodexWorkspaces(home());
    const workspaces = discovery.workspaces;
    const previous = bindingEntry?.context;
    const boundWorkspace = previous ? workspaces.find(item => item.id === previous.workspace_id) : null;
    if (previous && discovery.error && !workspaces.length) throw new Error(discovery.error);
    if (previous) {
      const assigned = previous.session ? resolveChatWorkspace(home(), previous.session) : null;
      if (!boundWorkspace || !(boundWorkspace.roots || [boundWorkspace.root]).includes(previous.root)
        || assigned && assigned.id !== previous.workspace_id || previous.session_mapped && assigned?.id !== previous.workspace_id) bindingEntry.invalid = true;
    }
    if (bindingEntry?.invalid) return { workspaces, context: { root: null, workspace_id: null, session_id: null, binding, binding_state: 'invalid', source: 'unavailable' }, discovery_error: discovery.error, note: '原工作区已删除或归属发生变化，定位已失效，请重新定位或手动选择工作区。' };
    const sessionWorkspace = args.session ? resolveChatWorkspace(home(), args.session) : null;
    const mapped = sessionWorkspace || boundWorkspace;
    const explicitRoot = args.root ? discoveredRoot(args.root) : null;
    if (mapped && explicitRoot && !(mapped.roots || [mapped.root]).includes(explicitRoot)) throw new Error('聊天归属与所选工作区不一致');
    const rootMatches = explicitRoot ? workspaces.filter(item => (item.roots || [item.root]).includes(explicitRoot)) : [];
    if (!mapped && rootMatches.length > 1) throw new Error('根目录属于多个工作区，无法唯一定位；请提供真实聊天 session 或手动选择工作区');
    const workspace = mapped || rootMatches[0] || null;
    const root = previous?.root || mapped?.root || explicitRoot || null;
    if (binding && (args.root || args.session)) {
      if (!workspace) throw new Error('自动定位需要当前聊天的真实工作区');
      if (previous && ((previous.session || null) !== (args.session || null) || previous.root !== root || previous.workspace_id !== workspace.id)) throw new Error('定位请求已绑定其他聊天');
      bindingEntry.context = { root, workspace_id: workspace.id, session_mapped: Boolean(sessionWorkspace) || previous?.session_mapped === true, ...(args.session ? { session: args.session } : {}) };
    }
    return { workspaces, context: { root, workspace_id: workspace?.id || null, session_id: args.session || null, ...(binding ? { binding } : {}), source: sessionWorkspace ? 'thread-project-assignment' : boundWorkspace ? 'panel-binding' : explicitRoot ? 'explicit' : 'unavailable' }, discovery_error: discovery.error, recency: discovery.recency, note: '选择工作区不会启用工作流；红绿状态以保存结果为准。没有可靠聊天上下文时请手选工作区。代理状态为最后观察。'+(discovery.recency?.reason?' '+discovery.recency.reason:'') };
  };
  const workspaceFor = id => {
    const found = readCodexWorkspaces(home()).workspaces.find(item => item.id === id);
    if (!found) throw new Error('工作区已删除或不可用，请刷新列表');
    return found;
  };
  let initialized = false;
  async function request(message) {
    if (!message || typeof message !== 'object' || Array.isArray(message) || message.jsonrpc !== '2.0' || typeof message.method !== 'string') {
      return rpcError(message?.id ?? null, -32600, '无效 JSON-RPC 请求');
    }
    const id = Object.hasOwn(message, 'id') ? message.id : undefined;
    const params = message.params && typeof message.params === 'object' && !Array.isArray(message.params) ? message.params : {};
    try {
      if (message.method === 'initialize') return { jsonrpc: '2.0', id, result: initializeResult() };
      if (message.method === 'notifications/initialized' || message.method === 'notifications/cancelled') { initialized = true; return null; }
      if (message.method === 'ping') return { jsonrpc: '2.0', id, result: {} };
      if (message.method === 'server/discover') return { jsonrpc: '2.0', id, result: {
        resultType: 'complete', supportedVersions: [PROTOCOL_VERSION],
        _meta: { 'io.modelcontextprotocol/serverInfo': { name: SERVER_NAME, version: SERVER_VERSION } },
        capabilities: { tools: {}, extensions: { 'openai/settings': { readTool: READ_TOOL, updateTool: UPDATE_TOOL } } },
      } };
      if (message.method === 'tools/list') return { jsonrpc: '2.0', id, result: { tools: toolList } };
      if (message.method === 'resources/list') return { jsonrpc: '2.0', id, result: { resources: [{ uri: DASHBOARD_URI, name: 'AI Loop 工作流', title: 'AI Loop 工作流', description: '统一工作区配置与纵向代理看板。', mimeType: 'text/html;profile=mcp-app' }] } };
      if (message.method === 'resources/read') {
        if (params.uri !== DASHBOARD_URI) throw new Error('未知看板资源');
        return { jsonrpc: '2.0', id, result: { contents: [{ uri: DASHBOARD_URI, mimeType: 'text/html;profile=mcp-app', text: dashboardHtml(), _meta: { 'openai/ui': { availableDisplayModes: ['inline', 'fullscreen'], preferredDisplayMode: 'fullscreen' } } }] } };
      }
      if (message.method === 'tools/call') {
        const name = params.name;
        const args = params.arguments && typeof params.arguments === 'object' && !Array.isArray(params.arguments) ? params.arguments : {};
        if (['ai_loop.panel.read', 'ai_loop.panel.update', 'ai_loop.panel.action'].includes(name)) {
          const allowed = name.endsWith('.update') ? ['panel_id', 'set'] : name.endsWith('.action') ? ['panel_id', 'action'] : ['panel_id'];
          if (Object.keys(args).some(key => !allowed.includes(key))) throw new Error('面板参数无效');
          const created = !panels.has(args.panel_id);
          const canCreate = name.endsWith('.read') || name.endsWith('.update') && args.set && ['workspace_id', 'workspace_root'].some(key => Object.hasOwn(args.set, key));
          const panel = panelFor(args.panel_id, canCreate);
          let result;
          if (name.endsWith('.read')) result = await panel.read();
          else if (name.endsWith('.update')) result = await panel.update(args.set);
          else {
            if (!['apply', 'discard', 'reset_project'].includes(args.action)) throw new Error('面板动作无效');
            const action = await panel.action('ai_loop.settings.' + args.action);
            result = { ...await panel.read(), action_result: action };
          }
          return { jsonrpc: '2.0', id, result: toolResult({ ...result, panel_created: created }) };
        }
        if (name === READ_TOOL) {
          if (Object.keys(args).length) throw new Error('settings.read 不接受参数');
          const result = await manager.read();
          return { jsonrpc: '2.0', id, result: toolResult(result) };
        }
        if (name === UPDATE_TOOL) {
          if (!args.set || typeof args.set !== 'object' || Array.isArray(args.set) || Object.keys(args).some(key => key !== 'set')) throw new Error('settings.update 需要且只接受 set 对象');
          const result = await manager.update(args.set);
          return { jsonrpc: '2.0', id, result: toolResult(result) };
        }
        if (name === DASHBOARD_TOOL || name === DASHBOARD_READ_TOOL) {
          if (name === DASHBOARD_TOOL && Object.hasOwn(args, 'binding')) throw new Error('旧版自动消息定位入口已停用，请关闭旧面板后重新打开；不再发送定位消息。');
          const result = toolResult(dashboardData(args));
          if (name === DASHBOARD_TOOL) return { jsonrpc: '2.0', id, result: { ...result, _meta: { ui: { resourceUri: DASHBOARD_URI } } } };
          return { jsonrpc: '2.0', id, result };
        }
        if (['ai_loop.dashboard.runs', 'ai_loop.dashboard.history'].includes(name) && args.workspace_id !== undefined) {
          const history = name.endsWith('.history');
          if (Object.keys(args).some(key => !['workspace_id', 'session', ...(history ? ['after'] : [])].includes(key))) throw new Error('工作区查询参数无效');
          const workspace = workspaceFor(args.workspace_id);
          const roots = workspace.roots || [workspace.root];
          if (history && !args.session) throw new Error('聊天历史需要真实 session');
          if (args.session !== undefined && (typeof args.session !== 'string' || !args.session.trim() || args.session.length > 1000)) throw new Error('聊天标识无效');
          const mapped = args.session ? resolveChatWorkspace(home(), args.session) : null;
          if (mapped && mapped.id !== workspace.id) throw new Error('聊天不属于此工作区');
          if (!history) {
            const runs = roots.flatMap(root => (args.session === undefined ? listRuns(root) : sessionRuns(root, args.session).map(round => round.run)).map(run => ({ ...run, record_root: root })));
            runs.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')) || a.record_root.localeCompare(b.record_root) || a.run_id.localeCompare(b.run_id));
            return { jsonrpc: '2.0', id, result: toolResult({ workspace_id: workspace.id, runs }) };
          }
          const rounds = []; let unbound_count = 0, unbound_activity_count = 0, unreadable_count = 0;
          for (const root of roots) {
            let after;
            do {
              const page = chatHistory(root, { session_id: args.session, harness: 'codex', limit: 100, after });
              rounds.push(...page.rounds.map(round => ({ ...round, root, activity: navigationActivity(root, args.session, round.activity, mapped) })));
              if (!after) { unbound_count += page.unbound_count; unbound_activity_count += page.unbound_activity_count; unreadable_count += page.unreadable_count || 0; }
              after = page.next_after;
            } while (after);
          }
          const key = round => JSON.stringify([round.run.created_at || '', round.root, round.run.project_path, round.run.run_id]);
          rounds.sort((a, b) => key(a) < key(b) ? 1 : key(a) > key(b) ? -1 : 0);
          let start = 0;
          if (args.after !== undefined) {
            let cursor;
            try { cursor = JSON.parse(Buffer.from(args.after, 'base64url').toString('utf8')); } catch { throw new Error('历史游标无效'); }
            if (cursor.workspace !== workspace.id || cursor.session !== args.session || typeof cursor.key !== 'string') throw new Error('历史游标不属于此工作区聊天');
            // 按稳定键向后翻页，原游标记录删除也不重复前页。
            start = rounds.findIndex(round => key(round) < cursor.key);
            if (start < 0) start = rounds.length;
          }
          const page = rounds.slice(start, start + 20);
          const next_after = start + page.length < rounds.length ? Buffer.from(JSON.stringify({ workspace: workspace.id, session: args.session, key: key(page.at(-1)) })).toString('base64url') : null;
          return { jsonrpc: '2.0', id, result: toolResult({ workspace_id: workspace.id, rounds: page, unbound_count, unbound_activity_count, unreadable_count, next_after }) };
        }
        if (name === 'ai_loop.dashboard.runs') {
          if (typeof args.root !== 'string' || Object.keys(args).some(key => !['root', 'session'].includes(key))) throw new Error('runs 需要 root 和可选 session');
          const root = discoveredRoot(args.root);
          return { jsonrpc: '2.0', id, result: toolResult({ root, runs: args.session === undefined ? listRuns(root) : sessionRuns(root, args.session).map(item => item.run) }) };
        }
        if (name === 'ai_loop.dashboard.status') {
          if (typeof args.root !== 'string' || typeof args.run !== 'string' || Object.keys(args).some(key => !['root', 'run', 'session', 'project_path'].includes(key))) throw new Error('status 需要 root 和 run');
          const root = discoveredRoot(args.root), run = validId(args.run);
          const bound = args.session === undefined ? null : sessionRuns(root, args.session).find(item => item.run.run_id === run && (args.project_path === undefined || item.run.project_path === args.project_path));
          if (args.session !== undefined && !bound) throw new Error('此运行不属于当前聊天');
          const scope = { project_path: args.project_path };
          const current = status(root, run, scope);
          const profile = resolveEffectiveProfile(root, { home: home() }).profile || disabledProfile('codex');
          const roles = Object.fromEntries(Object.entries(profile.roles).map(([role, value]) => [role, { enabled: roleEnabled(value), model: value.model }]));
          const observed = bound?.activity ?? activityStatus(root, run, scope);
          const activity = bound ? navigationActivity(root, args.session, observed, resolveChatWorkspace(home(), args.session)) : observed;
          return { jsonrpc: '2.0', id, result: toolResult({ root, run: current, roles, activity, events: events(root, run, Math.max(0, current.event_seq - 100), 100, scope).events }) };
        }
        if (name === 'ai_loop.dashboard.history') {
          if (typeof args.session !== 'string' || !args.session.trim() || args.session.length > 1000 || Object.keys(args).some(key => !['root', 'session', 'after'].includes(key))) throw new Error('history 需要真实 root/session 与可选 after');
          const root = discoveredRoot(args.root);
          const history = chatHistory(root, { session_id: args.session, harness: 'codex', after: args.after, limit: 20 });
          const workspace = resolveChatWorkspace(home(), args.session);
          const rounds = (history.rounds ?? []).map(round => ({ ...round, root, activity: navigationActivity(root, args.session, round.activity, workspace) }));
          return { jsonrpc: '2.0', id, result: toolResult({ root, ...history, rounds }) };
        }
        if (name === 'ai_loop.dashboard.navigation.verify') {
          if (typeof args.root !== 'string' || typeof args.session !== 'string' || typeof args.thread_id !== 'string' || Object.keys(args).some(key => !['root', 'session', 'thread_id'].includes(key))) throw new Error('navigation.verify 需要 root、session 与 thread_id');
          const root = discoveredRoot(args.root);
          return { jsonrpc: '2.0', id, result: toolResult(navigationProof(root, args.session, args.thread_id)) };
        }
        if (name === 'ai_loop.dashboard.navigation.resolve') {
          if (typeof args.root !== 'string' || typeof args.session !== 'string' || typeof args.agent_id !== 'string' || Object.keys(args).some(key => !['root', 'run', 'project_path', 'session', 'agent_id'].includes(key))) throw new Error('需要工作区、运行、父聊天和代理记录');
          const root = discoveredRoot(args.root), run = validId(args.run), agentId = validId(args.agent_id);
          const workspace = resolveChatWorkspace(home(), args.session);
          const samePath = (left, right) => process.platform === 'win32' ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase() : path.resolve(left) === path.resolve(right);
          if (!workspace?.roots?.some(member => samePath(member, root))) return { jsonrpc: '2.0', id, result: toolResult({ available: false, reason: '父聊天不属于当前工作区' }) };
          const observed = activityStatus(root, run, { project_path: args.project_path });
          const agent = observed.agents.find(item => item.id === agentId);
          if (!agent || agent.harness !== 'codex' || (agent.context?.parent_id && agent.context.parent_id !== args.session)) return { jsonrpc: '2.0', id, result: toolResult({ available: false, reason: '代理记录不存在或属于其他父聊天' }) };
          const proof = resolveCodexSubagent(home(), { agentPath: agent.native_id, agentRole: `loop-${agent.role}`, parentThreadId: args.session, roots: workspace.roots, startedAt: agent.started_at ?? null });
          return { jsonrpc: '2.0', id, result: toolResult(proof) };
        }
        if (typeof name === 'string' && ['ai_loop.settings.apply', 'ai_loop.settings.discard', 'ai_loop.settings.reset_project', 'ai_loop.workspace.toggle'].includes(name)) {
          if (Object.keys(args).length) throw new Error(`${name} 不接受参数`);
          const result = await manager.action(name);
          const text = result?.message || (result?.status ? `已完成：${result.status}` : result?.root ? `工作区：${result.root}` : '操作已完成');
          return { jsonrpc: '2.0', id, result: toolResult({ result }, text) };
        }
        return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: `未知工具：${String(name)}` }], isError: true } };
      }
      if (id === undefined) return null;
      return rpcError(id, -32601, `不支持的方法：${message.method}`);
    } catch (error) {
      if (message.method === 'tools/call') return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: String(error.message || error) }], isError: true } };
      return rpcError(id ?? null, -32603, String(error.message || error));
    }
  }
  return { request, get initialized() { return initialized; } };
}

export async function runSettingsServer(options = {}) {
  const input = options.input || process.stdin;
  const output = options.output || process.stdout;
  const protocol = options.protocol || createSettingsProtocol(options.manager || createSettingsManager(options.managerOptions));
  let queue = Promise.resolve();
  let pending = Buffer.alloc(0), dropping = false;
  const send = value => { if (value) output.write(`${JSON.stringify(value)}\n`); };
  const enqueueLine = line => {
    queue = queue.then(async () => {
      let message;
      try { message = JSON.parse(line); }
      catch { send(rpcError(null, -32700, '无效 JSON')); return; }
      send(await protocol.request(message));
    }).catch(error => { send(rpcError(null, -32603, String(error.message || error))); });
  };
  const oversized = () => send(rpcError(null, -32700, 'JSON-RPC 输入超过 1 MiB'));
  input.on('data', chunk => {
    const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    let start = 0;
    while (start < data.length) {
      const newline = data.indexOf(10, start);
      const end = newline < 0 ? data.length : newline;
      const segment = data.subarray(start, end);
      if (dropping) {
        if (newline < 0) return;
        dropping = false; pending = Buffer.alloc(0); start = newline + 1; continue;
      }
      if (pending.length + segment.length > MAX_LINE_BYTES) {
        oversized(); pending = Buffer.alloc(0); dropping = newline < 0;
      } else {
        pending = Buffer.concat([pending, segment]);
        if (newline >= 0) {
          enqueueLine(pending.toString('utf8').replace(/\r$/, ''));
          pending = Buffer.alloc(0);
        }
      }
      if (newline < 0) break;
      start = newline + 1;
    }
  });
  input.on('error', error => { queue = queue.then(() => { throw error; }); });
  await new Promise((resolve, reject) => { input.once('end', resolve); input.once('error', reject); });
  if (pending.length && !dropping) enqueueLine(pending.toString('utf8').replace(/\r$/, ''));
  await queue;
}

if (mainModule(import.meta.url)) {
  runSettingsServer().catch(error => { process.stderr.write(`AI Loop settings MCP: ${error.message || error}\n`); process.exitCode = 1; });
}
