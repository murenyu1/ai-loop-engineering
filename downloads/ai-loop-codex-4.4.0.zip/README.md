# AI Loop Codex 插件 4.3.1

4.3.1 修复纯插件项目调度预检和 Windows 沙箱只读身份误报。插件预检使用 `node PLUGIN/scripts/plugin.mjs doctor --project ROOT`；兼容 `doctor.mjs` 也会识别插件项目。配置检查、原生执行、实际模型和界面分别验收。

在 Codex 插件详情页直接管理 AI Loop 模型和工作区，并在不同本地项目使用同一套开发闭环、分页记忆与中断恢复流程。插件包包含运行所需核心，无需另装通用工作流。可从 [GitHub Releases](https://github.com/murenyu1/ai-loop-engineering/releases/tag/v4.3.1) 单独下载 Codex 插件包。

## 安装

需要已登录的 Codex 和 Node.js 18+。解压插件包后，在插件目录以正常用户终端执行：

```powershell
node scripts/install-plugin.mjs --project .
node scripts/install-plugin.mjs --project . --apply
```

先预演，再安装。安装器使用 Codex 原生插件管理命令，不修改 `settings.json` 或钩子信任缓存。安装后新开聊天，核对技能是否加载。

## 在插件详情页配置

打开 Codex 的 AI Loop Engineering 插件详情页，使用原生设置区：

1. 在“Codex 工作区”中直接选择已有项目，选项显示项目名称和目录。打开设置时自动刷新本机列表，无需手填路径或登记。选择只读；新工作区默认停用，调整开关后点击“应用工作区开关”。
2. 选择“全局默认”或“仅当前工作区”范围；选中工作区后默认“仅当前工作区”。设置 planner、reviewer、dev、tester、scribe 的模型、支持的思考深度与并发，然后点击“应用模型配置”。修改字段先暂存草稿，按钮才保存；服务端再次检查模型和强度。
3. 项目覆盖只用于所选项目；使用恢复动作后项目继承全局默认。主会话模型仍由 Codex 自身选择器控制。

配置在原生重载后的后续派发中生效，已有代理不会热切换。模型配置成功、原生代理发现和真实推理生效是不同的验收状态。

应用、恢复后，退出并重新进入插件详情页查看最新结果。遇到其他窗口同时修改配置时，点击“放弃未应用草稿”后重新进入，避免覆盖外部修改。

插件详情页的设置入口取决于当前 Codex 客户端支持和功能开关。实际插件页面仍需在所用客户端验收；静态检查或自动测试不能证明页面已经显示。若设置区缺失，请核对当前插件版本和 Codex 页面状态；不建议用浏览器面板、私有功能开关、`settings.json` 或信任缓存绕过。

## 新聊天继续项目

设置页只读 Codex 保存的本机项目列表，保留旧 AI Loop 工作区配置；不存在或不可用的目录不会列入选项。选择工作区不会写配置，应用按钮才保存。本机列表适配 `CODEX_HOME/.codex-global-state.json` 中的项目记录与旧根目录列表；这是桌面版本兼容层，文件缺失、损坏或格式改变会在设置页明确提示，并保留仍存在的旧工作区供选择。插件不会修改此文件。

自动恢复入口仍需在 Codex 原生 `/hooks` 页面审核并信任 SessionStart。安装插件和选择工作区不会代替信任审核；入口只对用户启用的精确项目根目录生效，子目录不自动继承。

每个项目只保存自己的 `.ai-loop/` 运行资料。中断后可恢复已落盘的摘要、未关闭工作单元、事件和改动定位；未记录的聊天内容无法恢复。选择工作区不授予提交、发布或越权权限。Windows 受保护配置需由正常用户宿主创建；不批量调整权限。

通用工作流、源码布局和已发布版本见[项目首页](https://github.com/murenyu1/ai-loop-engineering)；版本包见 [v4.3.1 Releases](https://github.com/murenyu1/ai-loop-engineering/releases/tag/v4.3.1)，通用工作流与 Codex 插件可分别下载。
